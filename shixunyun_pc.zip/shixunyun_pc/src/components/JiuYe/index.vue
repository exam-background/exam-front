<template>
  <div>
    <el-form ref="form" :model="form" label-width="80px">
      <el-form-item>
        <el-button type="primary" size="small" icon="el-icon-plus" @click="insert=true">新增</el-button>
        <el-button type="danger" size="small" icon="el-icon-delete">删除</el-button>
        <el-button type="primary" size="small" icon="el-icon-s-data" @click="bili">科目/题目分数占比</el-button>
        <!-- 新增弹窗 -->
        <el-dialog title="新增" :visible.sync="insert" class="insert">
          <el-form :model="form">
            <el-form-item label="考试时间" :label-width="formLabelWidth">
              <div class="block">
                <el-date-picker v-model="value1" type="datetime" placeholder="选择日期时间"></el-date-picker>
              </div>
            </el-form-item>
            <el-form-item label="班级名称" :label-width="formLabelWidth">
              <el-input v-model="form.name" autocomplete="off" style="width:217px"></el-input>
            </el-form-item>
            <el-form-item label="专业" :label-width="formLabelWidth" style="width:80%">
              <el-select v-model="form.a" placeholder="请选择活动区域">
                <el-option label="java" value="java"></el-option>
                <el-option label="前端" value="js"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="科目" :label-width="formLabelWidth" style="width:80%">
              <el-select v-model="form.b" placeholder="请选择活动区域">
                <el-option label="选择题" value="xuanze"></el-option>
                <el-option label="填空题" value="tiankongti"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="科目分数" :label-width="formLabelWidth">
              <el-input v-model="form.name" autocomplete="off" style="width:217px"></el-input>
            </el-form-item>
            <el-form-item label="题目" :label-width="formLabelWidth" style="width:80%">
              <el-select v-model="form.b" placeholder="请选择活动区域">
                <el-option label="选择题" value="xuanze"></el-option>
                <el-option label="填空题" value="tiankongti"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="题目分数" :label-width="formLabelWidth">
              <el-input v-model="form.name" autocomplete="off" style="width:217px"></el-input>
            </el-form-item>
          </el-form>
          <!-- 取消or保存 -->
          <div slot="footer" class="dialog-footer">
            <el-button @click="insertFrom = false">取 消</el-button>
            <el-button type="primary" @click="insertFrom = false">保 存</el-button>
          </div>
        </el-dialog>
      </el-form-item>
      <el-row class="inputRow">
        <el-col :span="7">
          <el-form-item label="考试时间" :label-width="formLabelWidth">
            <div class="block">
              <el-date-picker v-model="value1" type="datetime" placeholder="选择日期时间"></el-date-picker>
            </div>
          </el-form-item>
        </el-col>
        <el-col :span="4">
          <el-form-item label="专业">
            <el-input v-model="form.name" placeholder="请输入内容"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="4">
          <el-form-item label="班级">
            <el-select v-model="form.region" placeholder="请选择">
              <el-option label="JAVA" value="S1"></el-option>
              <el-option label=".NET" value="S2"></el-option>
              <el-option label="前端" value="Y2"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="5">
          <el-form-item label="科目">
            <el-select v-model="form.region" placeholder="请选择">
              <el-option label="JAVA" value="S1"></el-option>
              <el-option label=".NET" value="S2"></el-option>
              <el-option label="前端" value="Y2"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="3">
          <el-form-item style="text-align:right;">
            <el-button type="primary">查询</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <el-table
      ref="multipleTable"
      :data="tableData.slice((currentPage-1)*pagesize,currentPage*pagesize)"
      max-height="395"
      tooltip-effect="dark"
      style="width: 100%"
      align="center"
      :cell-style="cellStyle"
      :header-cell-style="rowClass"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column prop="DateTime" label="考试时间"></el-table-column>
      <el-table-column prop="Class" label="班级"></el-table-column>
      <el-table-column prop="zhuanYe" label="专业"></el-table-column>
      <el-table-column prop="kemufenshu" label="科目总分">
        <template slot-scope="scope">
              <a @click="kemuBi=true">{{ scope.row.kemufenshu }}</a>
              <!-- 科目分数占比 -->
        <el-dialog title="科目分数占比" :visible.sync="kemuBi" class="insert">
        <div class="yunClear">
              <label for="" class="yunLeft" style="width:10%">Vue</label><el-progress :text-inside="true" :stroke-width="26" :percentage="70" style="width:80%" class="yunLeft"></el-progress>
        </div>
        <div class="yunClear">
              <label for="" class="yunLeft" style="width:10%">Js</label><el-progress :text-inside="true" :stroke-width="24" :percentage="100" status="success" style="width:80%" class="yunLeft"></el-progress>
        </div>
        <div class="yunClear">
              <label for="" class="yunLeft" style="width:10%">小程序</label><el-progress :text-inside="true" :stroke-width="22" :percentage="80" status="warning" style="width:80%" class="yunLeft"></el-progress>
        </div>
          <!-- 取消or保存 -->
          <div slot="footer" class="dialog-footer">
            <el-button @click="insertFrom = false">取 消</el-button>
            <el-button type="primary" @click="insertFrom = false">保 存</el-button>
          </div>
        </el-dialog>
        </template>
      </el-table-column>
      <el-table-column prop="timufenshu" label="题目总分" show-overflow-tooltip>
        <template slot-scope="scope">
          <el-popover trigger="hover" placement="top">
            <p>Vuex: 10分</p>
            <p>route: 10分</p>
            <p>组件: 10分</p>
            <div slot="reference" class="name-wrapper">
              <el-tag size="medium">{{ scope.row.kemufenshu }}</el-tag>
            </div>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column fixed="right" label="操作">
        <template slot-scope="scope">
          <el-button
            @click.native.prevent="deleteRow(scope.$index, tableData)"
            type="text"
            size="small"
          >移除</el-button>
          <el-button
            @click.native.prevent="deleteRow(scope.$index, tableData)"
            type="text"
            size="small"
          >修改</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      background
      :page-size="pagesize"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      layout="total, prev, pager, next"
      :total="tableData.length"
    ></el-pagination>
  </div>
</template>
<script>
export default {
  name: 'JiuYe',
  data () {
    return {
      tableData: [
        {
          id: '0',
          DateTime: '2019-09-09',
          Class: 'T218',
          zhuanYe: '前端',
          kemufenshu: '100',
          timufenshu: '100'
        },
        {
          id: '0',
          DateTime: '2019-09-09',
          Class: 'T218',
          zhuanYe: '前端',
          kemufenshu: '100',
          timufenshu: '100'
        },
        {
          id: '0',
          DateTime: '2019-09-09',
          Class: 'T218',
          zhuanYe: '前端',
          kemufenshu: '100',
          timufenshu: '100'
        },
        {
          id: '0',
          DateTime: '2019-09-09',
          Class: 'T218',
          zhuanYe: '前端',
          kemufenshu: '100',
          timufenshu: '100'
        },
        {
          id: '0',
          DateTime: '2019-09-09',
          Class: 'T218',
          zhuanYe: '前端',
          kemufenshu: '100',
          timufenshu: '100'
        },
        {
          id: '0',
          DateTime: '2019-09-09',
          Class: 'T218',
          zhuanYe: '前端',
          kemufenshu: '100',
          timufenshu: '100'
        },
        {
          id: '0',
          DateTime: '2019-09-09',
          Class: 'T218',
          zhuanYe: '前端',
          kemufenshu: '100',
          timufenshu: '100'
        }
      ],
      form: {
        name: '',
        region: ''
      },
      pagesize: 10,
      currentPage: 1,
      insert: false,
      insertFrom: false,
      formLabelWidth: '120px',
      kemuBi: false
    }
  },
  methods: {
    cellStyle ({ row, column, rowIndex, columnIndex }) {
      // 表格文字居中
      return 'text-align:center'
    },
    rowClass ({ row, rowIndex }) {
      return 'text-align:center'
    },
    // 初始页currentPage、初始每页数据数pagesize和数据data
    handleSizeChange: function (size) {
      this.pagesize = size
      console.log(this.pagesize) // 每页下拉显示数据
    },
    handleCurrentChange: function (currentPage) {
      this.currentPage = currentPage
      console.log(this.currentPage) // 点击第几页
    },
    handleSelectionChange (val) {
      console.log(val)
    },
    bili () {
      this.drawer = true
      const arr = []
      const arr2 = []
      for (var i = 0; i < this.tableData.length; i++) {
        arr2.push({
          timu: this.tableData[i].timu,
          timufenshu: this.tableData[i].timufenshu
        })
        arr.push({
          kemu: this.tableData[i].kemu,
          kemufenshu: this.tableData[i].kemufenshu
        })
      }
      this.chartData.rows = arr
      this.chartData2.rows = arr2
    }
  }
}
</script>

<style scoped>
a{
  cursor: pointer;
}
.insert .el-form-item {
  margin: 20px 0;
}
.insert .yunClear{
  margin: 20px 0;
}
.el-drawer__body h3 {
  font: 700 16px "宋体";
  text-indent: 2em;
  line-height: 40px;
}
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
.inputRow {
  margin-top: 20px;
}
.StuData::-webkit-scrollbar {
  width: 4px;
}

.StuData::-webkit-scrollbar-thumb {
  background: transparent;
  border-radius: 4px;
}

.StuData:hover::-webkit-scrollbar-thumb {
  background: hsla(0, 0%, 53%, 1);
}

.StuData:hover::-webkit-scrollbar-track {
  background: hsla(0, 0%, 53%, 0.1);
}
.your-table .el-table__body-wrapper::-webkit-scrollbar {
  width: 10px;
  height: 10px;
}
</style>
